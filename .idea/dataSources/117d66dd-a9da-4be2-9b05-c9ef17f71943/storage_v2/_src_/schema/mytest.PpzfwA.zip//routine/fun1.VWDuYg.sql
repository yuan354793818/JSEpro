create function fun1(aa int, bb int)
  returns int
  BEGIN
	return aa + bb;
END;

