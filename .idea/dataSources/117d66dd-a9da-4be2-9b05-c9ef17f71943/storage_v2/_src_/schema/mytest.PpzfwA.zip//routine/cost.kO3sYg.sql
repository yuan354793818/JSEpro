create procedure cost(IN money int, IN uid int, OUT result int)
  BEGIN 
		DECLARE c TIMESTAMP;
		START TRANSACTION;
		SELECT SYSDATE() INTO c;
		IF(c > STR_TO_DATE("2019-12-12",'%Y-%m-%d')) THEN SET result = 1;
		END if;
		UPDATE person SET balance = balance - money WHERE id = uid;
		COMMIT;
	END;

