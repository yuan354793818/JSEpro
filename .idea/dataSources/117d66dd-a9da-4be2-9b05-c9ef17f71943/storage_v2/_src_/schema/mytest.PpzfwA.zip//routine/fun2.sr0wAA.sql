create procedure fun2()
  BEGIN 

	
	DECLARE money INT DEFAULT 0;
	DECLARE totalsal INT DEFAULT 0;
	
	DECLARE no_more_record INT DEFAULT  0;
	DECLARE no1_cursor CURSOR for SELECT balance FROM person;
	DECLARE CONTINUE HANDLER FOR NOT found SET no_more_record = 1;
	OPEN no1_cursor;
	
	circle1: LOOP
		IF no_more_record = 1 THEN 
				LEAVE circle1; 
		END IF; 
		
		FETCH no1_cursor INTO money;
		
		IF money is not null THEN
			SET totalsal = totalsal + money;
		END if;
	END LOOP circle1;

  CLOSE no1_cursor;

  SELECT totalsal;

END;

